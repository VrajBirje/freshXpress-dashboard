export default function NotFound() {
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-red-500 text-xl">Farmer not found</p>
      </div>
    );
  }